#!/bin/bash
set -e
cd BackendServiceImpl/Hello-Service/
mvn install
